# 🚀 Cybersecurity Scanning Project (Nmap + OWASP ZAP)

A hands-on cybersecurity project demonstrating **network scanning** using **Nmap** and **web application security scanning** using **OWASP ZAP**.  
This project is designed for **students, beginners, bug bounty hunters, and cybersecurity portfolio building**.

---

## 📌 Project Objectives

- Perform **network enumeration** using Nmap  
- Perform **web vulnerability scanning** using OWASP ZAP  
- Automate scans using simple scripts  
- Store reports for documentation and analysis  
- Provide a clean structure for showcasing cybersecurity work on GitHub  

---

## 📁 Project Structure

```
cybersec-nmap-zap-project/
│
├── nmap_scan.sh       # Script for Nmap network scanning
├── zap_scan.sh        # Script for OWASP ZAP baseline scanning
├── README.md          # Documentation (this file)
└── report/            # Folder where scan reports will be generated
```

---

## 🛠 Tools Used

### 🔍 Nmap
Used for:
- Discovering hosts  
- Finding open ports  
- OS & service fingerprinting  
- Vulnerability discovery  

### 🛡 OWASP ZAP
Used for:
- Web vulnerability scanning  
- Security header analysis  
- Passive & active scanning  

---

## ✔ Requirements

### **Nmap**
Install on Linux:
```
sudo apt install nmap
```

### **Docker (for ZAP)**
https://docs.docker.com/get-docker/

---

## 🚀 Usage

### ▶ Run Nmap scan
```
bash nmap_scan.sh
```

### ▶ Run ZAP scan
```
bash zap_scan.sh
```

Reports will be stored inside the **report/** folder.

---

## ⚠ Legal Disclaimer
Run scans **only on systems you own or have permission to test**.  
Unauthorized scanning is illegal.

---

## ⭐ Future Enhancements
- Add CI/CD pipeline  
- Add Python scanner scripts  
- Add vulnerable lab (Juice Shop)  

---

## ❤️ Support
If you like this project, ⭐ star it on GitHub!
