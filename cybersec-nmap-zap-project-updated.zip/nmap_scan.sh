#!/bin/bash
TARGET="scanme.nmap.org"
OUTPUT="report/nmap_report.txt"

mkdir -p report

echo "[*] Running Nmap scan on $TARGET ..."
nmap -A -oN $OUTPUT $TARGET
echo "[+] Scan complete. Report saved to $OUTPUT"
