#!/bin/bash
TARGET="https://example.com"
OUTPUT="report/zap_report.html"

mkdir -p report

echo "[*] Running OWASP ZAP Baseline Scan on $TARGET ..."
docker run -v $(pwd)/report:/zap/wrk/:rw -t owasp/zap2docker-stable     zap-baseline.py -t $TARGET -r zap_report.html

echo "[+] Scan complete. Report saved to $OUTPUT"
